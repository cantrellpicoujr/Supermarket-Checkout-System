import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

import javax.swing.*;

public class paymentController implements ActionListener {
	
	private JFrame customerDisplayFrame = new JFrame();
	private JFrame cashierDisplayFrame = new JFrame();
	private JFrame receiptDisplayFrame = new JFrame();
	private JFrame customerKeypadDisplayFrame = new JFrame();
	
	private JPanel customerDisplayPanel = new JPanel();
	private JPanel cashierDisplayPanel = new JPanel();
	private JPanel receiptDisplayPanel = new JPanel();
	private JPanel customerKeypadDisplayPanel = new JPanel();
	
	private JLabel welcomeLabel;
	private JLabel totalLabel;
	private JLabel cashAmountLabel;
	private JLabel changeAmountLabel;
	private JLabel cashFailedLabel;
	private JLabel ccNumberLabel;
	private JLabel dcNumberLabel;
	private JLabel pinLabel;
	private JLabel checkLabel;
	private JLabel pendingLabel;
	private JLabel paymentFailedLabel;
	private JLabel waitingLabel;
	private JLabel firstLabel;
	private JLabel lastLabel;
	private JLabel transSuccessLabel;
	
	private JButton cashButton;
	private JButton cardButton;
	private JButton checkButton;
	private JButton noneButton;
	private JButton confirmButton;
	private JButton creditButton;
	private JButton debitButton;
	private JButton oneButton;
	private JButton twoButton;
	private JButton threeButton;
	private JButton fourButton;
	private JButton fiveButton;
	private JButton sixButton;
	private JButton sevenButton;
	private JButton eightButton;
	private JButton nineButton;
	private JButton zeroButton;
	private JButton deleteButton;
	private JButton enterButton;
	private JButton enterButton2;
	private JButton dotButton;
	private JButton proceedButton;
	private JButton newOrderButton;
	
	private JTextField weightFirstTextField;
	private JTextField weightLastTextField;
	
	private JTextArea TextArea; //^
	private JTextArea customerTextArea; //^
	private JTextArea recieptTextArea;
	 
	int W = 1000;
	int H = 1000;
	int choice = 0;
	int loop = 0;
	int num = 0;
	double tmp;
	double total = 0;
	double ptTotal;
	double taxTotal = 0;
	double cash = 0;
	double change = 0;
	double checkAmount = 0;
	String name = "";
	String pNumber = "";
	String ccNumber;
	String pin;
	String authNum;
	boolean enterPressed = false;
	
	ArrayList<loyaltyAccounts> loyaltyAcc;
	ArrayList<inventory> cart;
	
	checkoutController obj = new checkoutController();
	fileParser obj2 = new fileParser();
	loyaltyController obj3 = new loyaltyController(); 
	
	String makeDate() {
		String tmp;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now = LocalDateTime.now();
		tmp = dtf.format(now);
		
		return tmp;
	}
	
	String makeTime() {
		String tmp;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		tmp = dtf.format(now);
		
		return tmp;
	}
	
	public void addCartPoints(int points) {
		pNumber = obj3.getNum();
		if(pNumber.length() == 10) {
			try {
				obj2.addPoints(pNumber, points);
			} catch (org.json.simple.parser.ParseException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		
		
	}
	
	public void printCart() {
		cart = obj.getOrder();
			
		for(inventory item:cart) {
			tmp = (item.getPrice()) * (item.getQuantityPurchased());
			total += tmp;	
		}
		ptTotal = total;
		ptTotal = Math.round(ptTotal*100.0)/100.0;
	}
	
	
	
	public void decreaseInventory(int quantity, String item) {
		try {
			obj2.decreaseInventoryQuantity(item,quantity);
		} catch (IOException | org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	String getAuthorization(String ccNum, String ccPin, double total) {
		
		buffer buff = new buffer();
		store storeObj = new store(buff, ccNum, ccPin, total);
		bank bankObj = new bank(buff);

		try { 
			bankObj.t.join();
			storeObj.t.join();
			
		} catch(InterruptedException e) {
			
		}
		
		return buff.reply;
		
	}
	
	public static String removeLastChar(String str) {
		   String result = null;
		   if ((str != null) && (str.length() > 0)) {
		      result = str.substring(0, str.length() - 1);
		   }
		   return result;
	}
	
	public double toDouble(String str) {
		double temp = Double.parseDouble(str); 
		
		return temp;
	}
	
	double calculateTotal(double preTaxTotal) {
		double tax = .0875;
		taxTotal = preTaxTotal * tax;
		taxTotal = Math.round(taxTotal*100.0)/100.0;
		preTaxTotal = preTaxTotal + (preTaxTotal * tax);
		preTaxTotal = Math.round(preTaxTotal*100.0)/100.0;
		
		return preTaxTotal;
	}
	
	void displayTotal() { 
		customerTextArea.setText("Total including tax: $" + total);
	}
	
	void createNumpad(int paymentChoice) {
		if(paymentChoice == 2 || paymentChoice == 3) { //numpad for card payment
			customerKeypadDisplayPanel.add(createTextArea());
			customerKeypadDisplayPanel.add(createDeleteButton());
			customerKeypadDisplayPanel.add(createOneButton());
			customerKeypadDisplayPanel.add(createTwoButton());
			customerKeypadDisplayPanel.add(createThreeButton());
			customerKeypadDisplayPanel.add(createFourButton());
			customerKeypadDisplayPanel.add(createFiveButton());
			customerKeypadDisplayPanel.add(createSixButton());
			customerKeypadDisplayPanel.add(createSevenButton());
			customerKeypadDisplayPanel.add(createEightButton());
			customerKeypadDisplayPanel.add(createNineButton());
			customerKeypadDisplayPanel.add(createZeroButton());
			customerKeypadDisplayPanel.add(createEnter2Button());
		} else if(paymentChoice == 1) { //numpad for cash payment
			cashierDisplayPanel.add(createCashDisplayMessage());
			cashierDisplayPanel.add(createTextArea());
			cashierDisplayPanel.add(createDeleteButton());
			cashierDisplayPanel.add(createOneButton());
			cashierDisplayPanel.add(createTwoButton());
			cashierDisplayPanel.add(createThreeButton());
			cashierDisplayPanel.add(createFourButton());
			cashierDisplayPanel.add(createFiveButton());
			cashierDisplayPanel.add(createSixButton());
			cashierDisplayPanel.add(createSevenButton());
			cashierDisplayPanel.add(createEightButton());
			cashierDisplayPanel.add(createNineButton());
			cashierDisplayPanel.add(createZeroButton());
			cashierDisplayPanel.add(createEnterButton());
			cashierDisplayPanel.add(createDotButton());
		} else if(paymentChoice == 4) { //numpad for check payment
			cashierDisplayPanel.add(createCheckDisplayMessage());
			cashierDisplayPanel.add(createTextArea());
			cashierDisplayPanel.add(createDeleteButton());
			cashierDisplayPanel.add(createOneButton());
			cashierDisplayPanel.add(createTwoButton());
			cashierDisplayPanel.add(createThreeButton());
			cashierDisplayPanel.add(createFourButton());
			cashierDisplayPanel.add(createFiveButton());
			cashierDisplayPanel.add(createSixButton());
			cashierDisplayPanel.add(createSevenButton());
			cashierDisplayPanel.add(createEightButton());
			cashierDisplayPanel.add(createNineButton());
			cashierDisplayPanel.add(createZeroButton());
			cashierDisplayPanel.add(createEnterButton3());
			cashierDisplayPanel.add(createDotButton());
		}
	}

	public void cashierDisplayFrame() {
		cashierDisplayFrame.setSize(W,400);
		cashierDisplayFrame.setTitle("CASHIER DISPLAY");
		cashierDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cashierDisplayFrame.setVisible(true); // true or false
		
		createCashierDisplayPanel();
		createCustomerDisplayFrame();
		
		cashierDisplayFrame.setContentPane(cashierDisplayPanel);
		cashierDisplayPanel.setVisible(true);
	}
	
	public void createCustomerDisplayFrame() {
		customerDisplayFrame.setSize(600,100);
		customerDisplayFrame.setTitle("CUSTOMER DISPLAY");
		customerDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		customerDisplayFrame.setVisible(false);
		
		createCustomerDisplayPanel();
		
		customerDisplayFrame.setContentPane(customerDisplayPanel);
		customerDisplayFrame.setVisible(true);
	}
	
	public void createCustomerKeypadDisplayFrame() {
		customerKeypadDisplayFrame.setSize(600,500);
		customerKeypadDisplayFrame.setTitle("CUSTOMER KEYPAD DISPLAY");
		customerKeypadDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		customerKeypadDisplayFrame.setVisible(true);
		
		createCustomerDisplayPanel3();
		
		customerKeypadDisplayFrame.setContentPane(customerKeypadDisplayPanel);
		customerKeypadDisplayFrame.setVisible(true);
	}
	
	public void createRecieptDisplayFrame() {
		receiptDisplayFrame.setSize(W,H);
		receiptDisplayFrame.setTitle("RECIEPT");
		receiptDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		receiptDisplayFrame.setVisible(true);
		
		createReceiptDisplayPanel();
		
		receiptDisplayFrame.setContentPane(receiptDisplayPanel);
		receiptDisplayPanel.setVisible(true);
	}
	
	
	JPanel createReceiptDisplayPanel() {
		receiptDisplayPanel.setLayout(null);
		receiptDisplayPanel.add(createRecieptTextArea());

		return receiptDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel() {
		customerDisplayPanel.setLayout(null);
		customerDisplayPanel.add(createCustomerDisplayTextArea());
		if(loop == 0) {
			total = calculateTotal(total);
		}
		loop += 1;
		displayTotal();
		
		return customerDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel2() {
		customerTextArea.setText("Change:" + change);
		
		return customerDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel3() {
		customerKeypadDisplayPanel.setLayout(null);
		customerKeypadDisplayPanel.add(createDebitButton());
		customerKeypadDisplayPanel.add(createCreditButton());

		return customerKeypadDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel4() {
		customerKeypadDisplayPanel.removeAll();
		customerKeypadDisplayPanel.updateUI();
		customerKeypadDisplayPanel.setLayout(null);
		if(choice == 2) {
			customerKeypadDisplayPanel.add(createDCNumberLabelDisplayMessage());	
			
		} else if(choice == 3) {
		 	customerKeypadDisplayPanel.add(createCCNumberLabelDisplayMessage());
		}
		createNumpad(choice);
		
		return customerDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel5() {
		customerDisplayPanel.removeAll();
		customerDisplayPanel.updateUI();
		customerDisplayPanel.add(createCashFailedDisplayMessage());
		
		return customerDisplayPanel;
	}
	
	JPanel createCashierDisplayPanel() {
		customerDisplayPanel.removeAll();
		customerDisplayPanel.updateUI();
		cashierDisplayPanel.setLayout(null);
		cashierDisplayPanel.add(createCashierDisplayMessage());
		cashierDisplayPanel.add(createCashierTotalMessage());
		cashierDisplayPanel.add(createCashButton());
		cashierDisplayPanel.add(createCardButton());
		cashierDisplayPanel.add(createCheckButton());
		cashierDisplayPanel.add(createNoneButton());
		
		return cashierDisplayPanel;
		
	}

	JPanel createCashierDisplayPanel2() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.setLayout(null);
		createNumpad(choice);

		return cashierDisplayPanel;
}

	JPanel createCashierDisplayPanel3() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.add(createChangeDisplayMessage());
		cashierDisplayPanel.add(createProceedButton2());
		
		return cashierDisplayPanel;
}
	
	JPanel createCashierDisplayPanel5() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.add(createPendingDisplayMessage());

		return cashierDisplayPanel;
	}
	
	JPanel createCashierDisplayPanel6() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.add(createCashFailedDisplayMessage());
		cashierDisplayPanel.add(createProceedButton());
		
		return cashierDisplayPanel;
	}
	
	JPanel createCashierDisplayPanel7() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.add(createWeightFirstTextField());
		cashierDisplayPanel.add(createWeightLastTextField());
		cashierDisplayPanel.add(createConfirmButton());
		cashierDisplayPanel.add(createFirstLabelDisplayMessage());
		cashierDisplayPanel.add(createLastLabelDisplayMessage());
		
		return cashierDisplayPanel;
	}
	
	JPanel createCashierDisplayPanel9() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.add(createPaymentFailedDisplayMessage());
		cashierDisplayPanel.add(createProceedButton3());
		
		return cashierDisplayPanel;
	}
	
	JLabel createFirstLabelDisplayMessage() {
		firstLabel = new JLabel("Enter first name:");
		firstLabel.setBounds(300,70,200,30);
		
		return firstLabel;
	}
	
	JLabel createLastLabelDisplayMessage() {
		lastLabel = new JLabel("Enter last name:");
		lastLabel.setBounds(300,110,200,30);
		
		return lastLabel;
	}
	
	JLabel createCheckDisplayMessage() {
		checkLabel = new JLabel("Enter check amount");
		checkLabel.setBounds(220,-100,1000,250);
		
		return checkLabel;
	}
	
	JLabel createNameDisplayMessage() {
		checkLabel = new JLabel("Enter full name");
		checkLabel.setBounds(395,-100,1000,250);
		
		return checkLabel;
	}
	
	JLabel createCashierDisplayMessage() {
		welcomeLabel = new JLabel("Select a form of payment");
		welcomeLabel.setBounds(395,-100,1000,250);
		
		return welcomeLabel;
	}
	
	JLabel createCashierTotalMessage() {
		totalLabel = new JLabel("Total: $" + calculateTotal(ptTotal));
		totalLabel.setBounds(395,-75,1000,250);
		
		return totalLabel;
	}
	
	
	JLabel createPendingDisplayMessage() {
		pendingLabel = new JLabel("Credit / Debit Transcation Pending ...");
		pendingLabel.setBounds(395,-100,1000,250);
		
		return pendingLabel;
	}
	
	JLabel createCashDisplayMessage() {
		cashAmountLabel = new JLabel("Enter cash amount:");
		cashAmountLabel.setBounds(200,-100,1000,250);
		
		return cashAmountLabel;
	}
	
	JLabel createChangeDisplayMessage() {
		change = cash - total;
		change = Math.round(change*100.0)/100.0;
		changeAmountLabel = new JLabel("Change amount: $" + change);
		changeAmountLabel.setBounds(395,-100,1000,250);
		
		return changeAmountLabel;
	}
	
	JLabel createCCNumberLabelDisplayMessage() {
		ccNumberLabel = new JLabel("Enter credit card number:");
		ccNumberLabel.setBounds(200,-100,1000,250);
		
		return ccNumberLabel;
	}
	
	JLabel createDCNumberLabelDisplayMessage() {
		dcNumberLabel = new JLabel("Enter debit card number:");
		dcNumberLabel.setBounds(200,-100,1000,250);
		
		return dcNumberLabel;
	}
	
	JLabel createPinLabelDisplayMessage() {
		pinLabel = new JLabel("Enter 4-digit pin:");
		pinLabel.setBounds(200,-100,1000,250);
		
		return pinLabel;
	}
	
	JLabel createCashFailedDisplayMessage() {
		cashFailedLabel = new JLabel("Error cash insufficient for purchase total");
		cashFailedLabel.setBounds(350,100,400,50);
		
		return cashFailedLabel;
	}
	
	JLabel createPaymentFailedDisplayMessage() {
		paymentFailedLabel = new JLabel("Payment Failed");
		paymentFailedLabel.setBounds(405,-30,1000,250);
		
		return paymentFailedLabel;
	}
	
	JLabel createWaitingCashierDisplayMessage() {
		waitingLabel = new JLabel("Waiting for Cashier...");
		waitingLabel.setBounds(200,-100,1000,250);
		
		return waitingLabel;
	}
	
	JLabel createTransSuccessLabelDisplayMessage() {
		transSuccessLabel = new JLabel("Transcation success");
		transSuccessLabel.setBounds(395,-100,1000,250);
		
		return transSuccessLabel;
	}
	
	JTextArea createCustomerDisplayTextArea() {
		customerTextArea = new JTextArea();
		customerTextArea.setBounds(100,0,400,50);
		customerTextArea.setEditable(false);
		
		return customerTextArea;
	}
	
	JTextArea createTextArea() {
		TextArea = new JTextArea();
		TextArea.setBounds(200,55,170,30);
		
		return TextArea;
	}
	
	JTextArea createRecieptTextArea() {
		recieptTextArea = new JTextArea();
		recieptTextArea.setBounds(240,220,500,250);
		recieptTextArea.setEditable(false);
		
		return recieptTextArea;
	}
	
	JTextField createWeightFirstTextField() {
		
		weightFirstTextField = new JTextField();
		weightFirstTextField.setBounds(550,70,100,30);
		
		return weightFirstTextField;
		
	}
	
	JTextField createWeightLastTextField() {
		
		weightLastTextField = new JTextField();
		weightLastTextField.setBounds(550,110,100,30);
		
		return weightLastTextField;
		
	}
	
	JButton createCashButton() {
		cashButton = new JButton("CASH");
		cashButton.setBounds(100,150,250,100);
		cashButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {	
				choice = 1;
				createCashierDisplayPanel2();
			}
			
		});
		
		return cashButton;
	}
	
	JButton createCardButton() {
		cardButton = new JButton("CARD");
		cardButton.setBounds(100,40,250,100);
		cardButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				createCashierDisplayPanel5();
				createCustomerKeypadDisplayFrame();
			}
			
		});
		
		return cardButton;
	}
	
	JButton createCheckButton() {
		checkButton = new JButton("CHECK");
		checkButton.setBounds(600,150,250,100);
		checkButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				choice = 4;
				createCashierDisplayPanel7();
			}
			
		});
		
		return checkButton;
	}
	
	JButton createNoneButton() {
		
		noneButton = new JButton("NONE");
		noneButton.setBounds(600,40,250,100);
		noneButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				customerDisplayPanel.removeAll();
				customerDisplayPanel.updateUI();
				receiptDisplayPanel.removeAll();
				receiptDisplayPanel.updateUI();
				customerKeypadDisplayPanel.removeAll();
				receiptDisplayPanel.updateUI();
				
				cashierDisplayFrame.setVisible(false);
				receiptDisplayFrame.setVisible(false);
				customerDisplayFrame.setVisible(false);
				customerKeypadDisplayFrame.setVisible(false);
				
				obj.checkOutFrame();
				obj.switchToCheckOutFrame();
				obj.clearCart();
			}
			
		});
		
		return noneButton;
	}
	
	JButton createConfirmButton() {
		
		confirmButton = new JButton("CONFIRM");
		confirmButton.setBounds(500,160,150,30);
		confirmButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				
				createCashierDisplayPanel2();
			}
			
		});
		
		return confirmButton;
	}
	
	JButton createOneButton() {
		
		oneButton = new JButton("1");
		oneButton.setBounds(200,90,50,50);

		
		oneButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("1");
				
			}
			
			
		});
		
		return oneButton;
		
		
	}
	
	JButton createTwoButton() {
		
		twoButton = new JButton("2");
		twoButton.setBounds(260,90,50,50);
		
		twoButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("2");
				
			}
			
		});
		
		return twoButton;
		
	}
	
	JButton createThreeButton() {
		
		threeButton = new JButton("3");
		threeButton.setBounds(320,90,50,50);
		
		threeButton.addActionListener( new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("3");
				
			}
			
		});
		
		return threeButton;
		
	}
	
	JButton createFourButton() {
		
		fourButton = new JButton("4");
		fourButton.setBounds(200,140,50,50);
		
		
		fourButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("4");
				
			}
			
		});
		
		return fourButton;
		
	}
	
	JButton createFiveButton() {
		
		fiveButton = new JButton("5");
		fiveButton.setBounds(260,140,50,50);
		
		
		fiveButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("5");
				
			}
			
		});
		
		return fiveButton;
		
	}
	
	JButton createSixButton() {
		
		sixButton = new JButton("6");
		sixButton.setBounds(320,140,50,50);
		
		
		sixButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("6");
				
			}
			
		});
		
		
		return sixButton;
		
	}
	
	JButton createSevenButton() {
		
		sevenButton = new JButton("7");
		sevenButton.setBounds(200,190,50,50);
		
		
		sevenButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("7");
				
			}
			
		});
		
		
		return sevenButton;
		
	}
	
	JButton createEightButton() {
		
		eightButton = new JButton("8");
		eightButton.setBounds(260,190,50,50);
	
		eightButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("8");
				
			}
			
		});
		
		
		return eightButton;
		
	}
	
	JButton createNineButton() {
		
		nineButton = new JButton("9");
		nineButton.setBounds(320,190,50,50);
		
		nineButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("9");
				
			}
			
		});
		
		
		return nineButton;
		
	}
	
	JButton createZeroButton() {
		
		zeroButton = new JButton("0");
		zeroButton.setBounds(260,240,50,50);
		
		
		zeroButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("0");
				
			}
			
		});
		
		
		return zeroButton;
		
	}
	
	JButton createDeleteButton() {
		
		deleteButton = new JButton("<-");
		deleteButton.setBounds(200,240,50,50);
		
		deleteButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				String temp = TextArea.getText();
				temp = removeLastChar(temp);
				TextArea.setText(temp);
				
			}
			
		});
		
		
		return deleteButton;
		
	}
	
	JButton createEnterButton() { //enter button for cash
		
		enterButton = new JButton("ENT");
		enterButton.setBounds(320,240,50,50);

		enterButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				String temp = TextArea.getText();
				cash = toDouble(temp);

				if(cash >= total) {
					createCashierDisplayPanel3();
					createCustomerDisplayPanel2();
				} else {
					createCustomerDisplayPanel5();
					createCashierDisplayPanel6();
				}

			}
			
		});
		
		
		return enterButton;
		
	}
	
	JButton createEnter2Button() {
		
		enterButton2 = new JButton("ENT");
		enterButton2.setBounds(320,240,50,50);
		
		enterButton2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String temp = TextArea.getText();
				
				if(num == 0) {
					ccNumber = temp;
					customerKeypadDisplayPanel.removeAll();
					customerKeypadDisplayPanel.updateUI();
					if(choice == 2) {
						customerKeypadDisplayPanel.add(createPinLabelDisplayMessage());
						num += 1;
						createNumpad(choice);
					} else {
						customerKeypadDisplayPanel.removeAll();
						customerKeypadDisplayPanel.updateUI();		

						
						authNum = getAuthorization(ccNumber, "0000", 1.00); //credit cards have a default pin of 0000
						if(authNum != "FALSE" ) {
							try {
								obj2.decAccBal(ccNumber, total);
								customerKeypadDisplayPanel.add(createTransSuccessLabelDisplayMessage());
								customerKeypadDisplayPanel.add(createProceedButton2());
							} catch (org.json.simple.parser.ParseException | IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} else {
							customerKeypadDisplayPanel.add(createWaitingCashierDisplayMessage());
							createCashierDisplayPanel9();
						}
					}
				} else if(num == 1 && choice == 2) { //for debit card pin
					pin = (temp);
					customerKeypadDisplayPanel.removeAll();
					customerKeypadDisplayPanel.updateUI();
					num = 0; 	
					authNum = getAuthorization(ccNumber, pin, 1.00);
					
					if(authNum != "FALSE" ) {
						try {
							obj2.decAccBal(ccNumber, total);
							customerKeypadDisplayPanel.add(createTransSuccessLabelDisplayMessage());
							customerKeypadDisplayPanel.add(createProceedButton2());
						} catch (org.json.simple.parser.ParseException | IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					} else {
						customerKeypadDisplayPanel.add(createWaitingCashierDisplayMessage());
						createCashierDisplayPanel9();
					}

				} 

			}
			
		});
		
		
		return enterButton2;
		
	}
	
	JButton createEnterButton3() { //enter button for cash
		
		enterButton = new JButton("ENT");
		enterButton.setBounds(320,240,50,50);

		enterButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				String temp = TextArea.getText();
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				checkAmount = toDouble(temp);
				if(checkAmount >= total) {
					cashierDisplayPanel.add(createTransSuccessLabelDisplayMessage());
					cashierDisplayPanel.add(createProceedButton2());
				} else {
					createCashierDisplayPanel9();
					
				}
			}
			
		});
		
		
		return enterButton;
		
	}
	
	JButton createDotButton() {
		
		dotButton = new JButton(".");
		dotButton.setBounds(260,290,50,50);
		
		dotButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
					
				TextArea.append(".");
				
				
			}
			
		});
		
		
		return dotButton;
		
	}
	
	JButton createNewOrderButton() { //used to start a new order
		newOrderButton = new JButton("New Order");
		newOrderButton.setBounds(360,40,250,100);
		
		newOrderButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				customerDisplayPanel.removeAll();
				customerDisplayPanel.updateUI();
				receiptDisplayPanel.removeAll();
				receiptDisplayPanel.updateUI();
				customerKeypadDisplayPanel.removeAll();
				receiptDisplayPanel.updateUI();
				
				cashierDisplayFrame.setVisible(false);
				receiptDisplayFrame.setVisible(false);
				customerKeypadDisplayFrame.setVisible(false);
				
				obj.checkOutFrame();
				obj.switchToCheckOutFrame();
				obj.clearCart();
				
				
			}
			
		});
		
		return newOrderButton;
	}
	
	JButton createProceedButton() { //used to go to payment screen when payment fails
		proceedButton = new JButton("Proceed");
		proceedButton.setBounds(350,140,250,100);
		
		proceedButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();

				createCashierDisplayPanel();
				createCustomerDisplayFrame();	
				
				
			}
			
		});
		
		return proceedButton;
	}
	
	JButton createProceedButton2() { //used when payment succeeds and prints receipt
		proceedButton = new JButton("Proceed");
		if(choice == 2 || choice == 3) {
			proceedButton.setBounds(340,40,250,100);
		} else{
			proceedButton.setBounds(340,40,250,100);
		}
		
		proceedButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				createRecieptDisplayFrame();
				customerDisplayFrame.setVisible(false);
				customerKeypadDisplayFrame.setVisible(false);
				for(inventory item:cart) {
					addCartPoints(item.getPoints() * item.getQuantityPurchased());
					decreaseInventory(item.getQuantityPurchased(),item.getId());
		
					recieptTextArea.append(item.getName());
					recieptTextArea.append("-----$" + item.getPrice());
					recieptTextArea.append("------Quantity/" + item.getQuantityPurchased());
					if(item.getBulk() == true) {
						recieptTextArea.append("------" + item.getWeight() + "kg\n");
					} else {
						recieptTextArea.append("\n");
					}
					
				}
				recieptTextArea.append("--------------------------------------------\n");
				recieptTextArea.append("Pretax: $" + ptTotal + "\n");
				recieptTextArea.append("Tax: $" + taxTotal + "\n");
				recieptTextArea.append("Total: $" + total + "\n");
				if(choice == 1) {
					recieptTextArea.append("Cash: $" + cash + "\n");
					recieptTextArea.append("Change: $" + change + "\n");
				} else if(choice == 2 || choice == 3) {
					recieptTextArea.append("Card number: " + ccNumber + "\n");
					recieptTextArea.append("Authorization code: " + authNum + "\n");
				} else if(choice == 4) {
					recieptTextArea.append("Check amount: $" + checkAmount + "\n");
					recieptTextArea.append("Date: " + makeDate() + "\n");
					recieptTextArea.append("Time: " + makeTime() + "\n");
					recieptTextArea.append("Store identy: Supermarket Store - 198 \n");
					recieptTextArea.append("Cashier identity: Ryan Perez \n");
				}
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				cashierDisplayPanel.add(createNewOrderButton());
			}
			
		});
		
		return proceedButton;
	}
	
	JButton createProceedButton3() { //used to go to payment screen when payment fails
		proceedButton = new JButton("Proceed");
		proceedButton.setBounds(340,110,250,100);
		
		proceedButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				
				customerKeypadDisplayFrame.setVisible(false);
				customerKeypadDisplayPanel.removeAll();
				customerKeypadDisplayPanel.updateUI();

				createCashierDisplayPanel();
				createCustomerDisplayFrame();	
				
				
			}
			
		});
		
		return proceedButton;
	}

	JButton createDebitButton() {
		
		debitButton = new JButton("DEBIT");
		debitButton.setBounds(30,120,250,200);
		
		debitButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				choice = 2;
				createCustomerDisplayPanel4();				
				
			}
			
		});
		
		
		return debitButton;
		
	}
	
	JButton createCreditButton() {
		
		creditButton = new JButton("CREDIT");
		creditButton.setBounds(320,120,250,200);
		
		
		creditButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				 
				choice = 3;
				createCustomerDisplayPanel4();
				
			}
			
		});
		
		
		return creditButton;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
	}
	

}
