import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.*;

public class paymentController implements ActionListener {
	
	private JFrame customerDisplayFrame = new JFrame();
	private JFrame cashierDisplayFrame = new JFrame();
	private JFrame receiptDisplayFrame = new JFrame();
	private JFrame customerKeypadDisplayFrame = new JFrame();
	
	private JPanel customerDisplayPanel = new JPanel(); //for total including tax
	private JPanel customerDisplayPanel2 = new JPanel(); //for change back
	private JPanel customerDisplayPanel3 = new JPanel(); //for credit or debit
	private JPanel customerDisplayPanel4 = new JPanel(); //for card information
	private JPanel cashierDisplayPanel = new JPanel(); //for payment option
	private JPanel cashierDisplayPanel2 = new JPanel(); //for cash amount:
	private JPanel cashierDisplayPanel3 = new JPanel(); //for change amount:
	private JPanel cashierDisplayPanel4 = new JPanel(); //for order cancelled
	private JPanel cashierDisplayPanel5 = new JPanel(); //for pending card transcation
	private JPanel receiptDisplayPanel = new JPanel();
	private JPanel customerKeypadDisplayPanel = new JPanel();
	
	private JLabel welcomeLabel;
	private JLabel cashAmountLabel;
	private JLabel changeAmountLabel;
	private JLabel cashFailedLabel;
	private JLabel ccNumberLabel;
	private JLabel dcNumberLabel;
	private JLabel cvcLabel;
	private JLabel expLabel;
	private JLabel pinLabel;
	private JLabel checkLabel;
	private JLabel pendingLabel;
	
	private JButton cashButton;
	private JButton cardButton;
	private JButton checkButton;
	private JButton noneButton;
	private JButton confirmButton;
	private JButton creditButton;
	private JButton debitButton;
	private JButton oneButton;
	private JButton twoButton;
	private JButton threeButton;
	private JButton fourButton;
	private JButton fiveButton;
	private JButton sixButton;
	private JButton sevenButton;
	private JButton eightButton;
	private JButton nineButton;
	private JButton zeroButton;
	private JButton deleteButton;
	private JButton enterButton;
	private JButton enterButton2;
	private JButton dotButton;
	private JButton proceedButton;
	private JButton newOrderButton;
	
	private JTextField weightTextField; //need explaining
	private JTextArea TextArea; //^
	private JTextArea TextArea2;
	private JTextArea customerOrder2TextArea; //^
	private JTextArea recieptTextArea;
	
	Boolean firstItemScanned = false;
	Boolean paymentSuccess = false;
	
	String weight = "0";
	
	//checkoutController checkout = new checkoutController();
	

	
	int W = 1000;
	int H = 1000;
	int choice = 0;
	int button = 0;
	int loop = 0;
	String ccNumber;
	String pin;
	int inc = 0;
	int num = 0; //keeps track of what input is asked for
	int num2 = 0;
	//int keypadUsed = 0; //1 if keypad is being used
	
	boolean debit = true;
	double total = 0;
	double ptTotal;
	double taxTotal = 0;
	double cash = 0;
	double change = 0;
	double checkAmount = 0;
	double tmp;
	String name = "";
	boolean enterPressed = false;
	
	String pNumber = "";
	
	ArrayList<loyaltyAccounts> loyaltyAcc;
	ArrayList<inventory> cart;
	
	
	checkoutController obj = new checkoutController();
	
	loyaltyController obj3 = new loyaltyController(); 
	
	fileParser obj2 = new fileParser();
	
	
	//System.out.println("Testing loyalty inside payment" + obj3.pNum);
	
	/**
	 * Place this block of code where the debit/credit will be called,
	 */
	
	/*
		buffer buff = new buffer();
		
		store storeObj = new store(buff, "1111111111111111", "1111", 1.00);
		
		bank bankObj = new bank(buff);
		
		
		try { 
			
			bankObj.t.join();
			storeObj.t.join();
			
		} catch(InterruptedException e) {
			
			
		}
		
		System.out.println(buff.reply); // makes sure you are getting back authorization number
	*/
	public void addCartPoints(int points) {
		
		//pNumber = obj3.getNum();
		pNumber = obj3.getNum();
		System.out.println("Phone number:" + pNumber);
		try {
			obj2.addPoints(pNumber, points);
		} catch (org.json.simple.parser.ParseException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("The total is" + total);
		
		
	}
	
	public void printCart() {
		
		cart = obj.getOrder();
		
		for(inventory item:cart) {
			
			System.out.println(item.getName());
			System.out.println(item.getQuantityPurchased());
			tmp = (item.getPrice()) * (item.getQuantityPurchased());
			total += tmp;
			
		}
		System.out.println("The total is" + total);
		
		
	}
	
	
	public static String removeLastChar(String str) {
		   String result = null;
		   if ((str != null) && (str.length() > 0)) {
		      result = str.substring(0, str.length() - 1);
		   }
		   return result;
	}
	
	public double toDouble(String str) {
		double temp = Double.parseDouble(str); 
		return temp;
	}
	
	public int toInt(String str) {
		int temp = Integer.parseInt(str); 
		return temp;
	}
	
	double calculateTotal(double preTaxTotal) {
		double tax = .0875;
		taxTotal = preTaxTotal * tax;
		taxTotal = Math.round(taxTotal*100.0)/100.0;
		preTaxTotal = preTaxTotal + (preTaxTotal * tax);
		preTaxTotal = Math.round(preTaxTotal*100.0)/100.0;
		return preTaxTotal;
	}
	
	void displayTotal() { 
		customerOrder2TextArea.setText("Total including tax: " + total);
	}
	
	void createNumpad(int paymentChoice) {
		if(paymentChoice == 2 || paymentChoice == 3) { //card numPad
			customerKeypadDisplayPanel.add(createTextArea());
			customerKeypadDisplayPanel.add(createDeleteButton());
			customerKeypadDisplayPanel.add(createOneButton());
			customerKeypadDisplayPanel.add(createTwoButton());
			customerKeypadDisplayPanel.add(createThreeButton());
			customerKeypadDisplayPanel.add(createFourButton());
			customerKeypadDisplayPanel.add(createFiveButton());
			customerKeypadDisplayPanel.add(createSixButton());
			customerKeypadDisplayPanel.add(createSevenButton());
			customerKeypadDisplayPanel.add(createEightButton());
			customerKeypadDisplayPanel.add(createNineButton());
			customerKeypadDisplayPanel.add(createZeroButton());
			customerKeypadDisplayPanel.add(createEnter2Button());
		} else if(paymentChoice == 1) { //cash numPad
			cashierDisplayPanel.add(createCashDisplayMessage());
			cashierDisplayPanel.add(createTextArea());
			cashierDisplayPanel.add(createDeleteButton());
			cashierDisplayPanel.add(createOneButton());
			cashierDisplayPanel.add(createTwoButton());
			cashierDisplayPanel.add(createThreeButton());
			cashierDisplayPanel.add(createFourButton());
			cashierDisplayPanel.add(createFiveButton());
			cashierDisplayPanel.add(createSixButton());
			cashierDisplayPanel.add(createSevenButton());
			cashierDisplayPanel.add(createEightButton());
			cashierDisplayPanel.add(createNineButton());
			cashierDisplayPanel.add(createZeroButton());
			cashierDisplayPanel.add(createEnterButton());
			cashierDisplayPanel.add(createDotButton());
		} else if(paymentChoice == 4) {
			//cashierDisplayPanel.add(createCashDisplayMessage());
			cashierDisplayPanel.add(createTextArea());
			cashierDisplayPanel.add(createDeleteButton());
			cashierDisplayPanel.add(createOneButton());
			cashierDisplayPanel.add(createTwoButton());
			cashierDisplayPanel.add(createThreeButton());
			cashierDisplayPanel.add(createFourButton());
			cashierDisplayPanel.add(createFiveButton());
			cashierDisplayPanel.add(createSixButton());
			cashierDisplayPanel.add(createSevenButton());
			cashierDisplayPanel.add(createEightButton());
			cashierDisplayPanel.add(createNineButton());
			cashierDisplayPanel.add(createZeroButton());
			cashierDisplayPanel.add(createEnterButton3());
			cashierDisplayPanel.add(createDotButton());
		}
	}
	
	JTextArea createCustomerDisplayTextArea() {
		
		customerOrder2TextArea = new JTextArea();
		customerOrder2TextArea.setBounds(100,0,400,50);
		customerOrder2TextArea.setEditable(false);
		
		return customerOrder2TextArea;
	}
	/**
	 * 
	 */
	public void cashierDisplayFrame() {
		
		cashierDisplayFrame.setSize(W,400);
		cashierDisplayFrame.setTitle("CASHIER DISPLAY");
		cashierDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cashierDisplayFrame.setVisible(true); // true or false
		
		createCashierDisplayPanel();
		createCustomerDisplayFrame();
		
		cashierDisplayFrame.setContentPane(cashierDisplayPanel);
		
		cashierDisplayPanel.setVisible(true);

	}
	
	public void createCustomerDisplayFrame() {
		
		customerDisplayFrame.setSize(600,100);
		customerDisplayFrame.setTitle("CUSTOMER DISPLAY");
		customerDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		customerDisplayFrame.setVisible(false);
		
		createCustomerDisplayPanel();
		
		customerDisplayFrame.setContentPane(customerDisplayPanel);
		
		customerDisplayFrame.setVisible(true);
		
		
	}
	
	public void createCustomerKeypadDisplayFrame() {
		
		customerKeypadDisplayFrame.setSize(600,500);
		customerKeypadDisplayFrame.setTitle("CUSTOMER KEYPAD DISPLAY");
		customerKeypadDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		customerKeypadDisplayFrame.setVisible(true);
		
		createCustomerDisplayPanel3();
		
		customerKeypadDisplayFrame.setContentPane(customerKeypadDisplayPanel);
		
		customerKeypadDisplayFrame.setVisible(true);
		
		
	}
	
	public void createRecieptDisplayFrame() {
		receiptDisplayFrame.setSize(W,H);
		receiptDisplayFrame.setTitle("RECIEPT");
		receiptDisplayFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		receiptDisplayFrame.setVisible(true); // true or false
		
		createReceiptDisplayPanel();
		
		receiptDisplayFrame.setContentPane(receiptDisplayPanel);
		receiptDisplayPanel.setVisible(true);
		
	}
	
	
	JPanel createReceiptDisplayPanel() {
		receiptDisplayPanel.setLayout(null);
		receiptDisplayPanel.add(createRecieptTextArea());

		return receiptDisplayPanel;
	}
	
	// Creates customer display panel and components 
	
	JPanel createCustomerDisplayPanel() {
		
		customerDisplayPanel.setLayout(null);
		customerDisplayPanel.add(createCustomerDisplayTextArea());
		ptTotal = total;
		ptTotal = Math.round(ptTotal*100.0)/100.0;
		if(loop == 0) {
			total = calculateTotal(total);
		}
		loop += 1;
		displayTotal();
		
		return customerDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel2() {
		
		//customerDisplayPanel.add(createCustomerDisplayTextArea());
		//if(cash)
		customerOrder2TextArea.setText("Change:" + change);
		
		return customerDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel3() {
		
		//customerDisplayPanel.setLayout(null);
		customerKeypadDisplayPanel.setLayout(null);
		
		customerKeypadDisplayPanel.add(createDebitButton());
		customerKeypadDisplayPanel.add(createCreditButton());

		return customerKeypadDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel4() {
		
		//customerDisplayPanel.setLayout(null);
		customerKeypadDisplayPanel.removeAll();
		customerKeypadDisplayPanel.updateUI();
		
			if(button == 0) { //credit
				customerKeypadDisplayPanel.setLayout(null);
				if(choice == 2) {
					customerKeypadDisplayPanel.add(createDCNumberLabelDisplayMessage());
					
		 		} else if(choice == 3) {
		 			customerKeypadDisplayPanel.add(createCCNumberLabelDisplayMessage());
				}
				createNumpad(choice);
				
				
			}
			
	
		return customerDisplayPanel;
	}
	
	JPanel createCustomerDisplayPanel5() {
		customerDisplayPanel.removeAll();
		customerDisplayPanel.updateUI();
		
		customerDisplayPanel.add(createCashFailedDisplayMessage());
		
		return customerDisplayPanel;
	}
	
	JTextArea createRecieptTextArea() {
		
		recieptTextArea = new JTextArea();
		recieptTextArea.setBounds(240,220,500,250);
		recieptTextArea.setEditable(false);
		
		return recieptTextArea;
	}
	
	JPanel createCashierDisplayPanel() {
		customerDisplayPanel.removeAll();
		customerDisplayPanel.updateUI();
		cashierDisplayPanel.setLayout(null);
		
		cashierDisplayPanel.add(createCashierDisplayMessage());
		cashierDisplayPanel.add(createCashButton());
		cashierDisplayPanel.add(createCardButton());
		cashierDisplayPanel.add(createCheckButton());
		cashierDisplayPanel.add(createNoneButton());
		//printAcc();
		
		return cashierDisplayPanel;
		
	}

	JPanel createCashierDisplayPanel2() {
	
	//cashierDisplayPanel.setLayout(null);
		
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		
		cashierDisplayPanel.setLayout(null);
		createNumpad(choice);

	return cashierDisplayPanel;
}

	JPanel createCashierDisplayPanel3() {
		
	//cashierDisplayPanel.setLayout(null);
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();
		cashierDisplayPanel.add(createChangeDisplayMessage());
		cashierDisplayPanel.add(createProceedButton2());
		return cashierDisplayPanel;
}
	
	JPanel createCashierDisplayPanel5() {
		
		//cashierDisplayPanel.setLayout(null);
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();

		cashierDisplayPanel.add(createPendingDisplayMessage());


		return cashierDisplayPanel;
	}
	
	JPanel createCashierDisplayPanel6() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();

		cashierDisplayPanel.add(createCashFailedDisplayMessage());
		cashierDisplayPanel.add(createProceedButton());
		
		return cashierDisplayPanel;
	}
	
	JPanel createCashierDisplayPanel7() {
		cashierDisplayPanel.removeAll();
		cashierDisplayPanel.updateUI();

		cashierDisplayPanel.add(createCheckDisplayMessage());
		createNumpad(choice);
		
		return cashierDisplayPanel;
	}
	
	JLabel createCheckDisplayMessage() {
		
		checkLabel = new JLabel("Enter check amount");
		checkLabel.setBounds(395,-100,1000,250);
		
		return checkLabel;
	}
	
	JLabel createNameDisplayMessage() {
		
		checkLabel = new JLabel("Enter full name");
		checkLabel.setBounds(395,-100,1000,250);
		
		return checkLabel;
	}
	
	JLabel createCashierDisplayMessage() {
		
		welcomeLabel = new JLabel("Select a form of payment");
		welcomeLabel.setBounds(395,-100,1000,250);
		
		return welcomeLabel;
	}
	
	JLabel createPendingDisplayMessage() {
		
		pendingLabel = new JLabel("Credit / Debit Transcation Pending ...");
		pendingLabel.setBounds(395,-100,1000,250);
		
		return pendingLabel;
	}
	
	JLabel createCashDisplayMessage() {
		
		cashAmountLabel = new JLabel("Enter cash amount:");
		cashAmountLabel.setBounds(200,-100,1000,250);
		
		return cashAmountLabel;
	}
	
	JLabel createChangeDisplayMessage() {
		
		change = cash - total;
		change = Math.round(change*100.0)/100.0;
		changeAmountLabel = new JLabel("Change amount: $" + change);
		changeAmountLabel.setBounds(395,-100,1000,250);
		
		return changeAmountLabel;
	}
	
	JLabel createCCNumberLabelDisplayMessage() {
		
		ccNumberLabel = new JLabel("Enter credit card number:");
		ccNumberLabel.setBounds(200,-100,1000,250);
		
		return ccNumberLabel;
	}
	
	JLabel createDCNumberLabelDisplayMessage() {
		
		dcNumberLabel = new JLabel("Enter debit card number:");
		dcNumberLabel.setBounds(200,-100,1000,250);
		
		return dcNumberLabel;
	}
	
	JLabel createPinLabelDisplayMessage() {
		
		pinLabel = new JLabel("Enter 4-digit pin:");
		pinLabel.setBounds(200,-100,1000,250);
		
		return pinLabel;
	}
	
	JLabel createCashFailedDisplayMessage() {
		cashFailedLabel = new JLabel("Error cash insufficient for purchase total");
		cashFailedLabel.setBounds(350,100,400,50);
		return cashFailedLabel;
	}
	
	JButton createCashButton() {
		
		cashButton = new JButton("CASH");
		cashButton.setBounds(100,150,250,100);
		cashButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				choice = 1;
				createCashierDisplayPanel2();
				
				//cashierDisplayPanel.removeAll();
				//cashierDisplayPanel
				//checkOutFrame();
				//switchToCheckOutFrame();
				
			}
			
		});
		
		return cashButton;
	}
	
	JButton createCardButton() {
		
		cardButton = new JButton("CARD");
		cardButton.setBounds(100,40,250,100);
		cardButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				//choice = 2;
				createCashierDisplayPanel5();
				createCustomerKeypadDisplayFrame();
				
				
			}
			
		});
		
		return cardButton;
	}
	
	JButton createCheckButton() {
		
		checkButton = new JButton("CHECK");
		checkButton.setBounds(600,150,250,100);
		checkButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				choice = 4;
				createCashierDisplayPanel7();
				//checkOutFrame();
				//switchToCheckOutFrame();
				
			}
			
		});
		
		return checkButton;
	}
	
	JButton createNoneButton() {
		
		noneButton = new JButton("NONE");
		noneButton.setBounds(600,40,250,100);
		noneButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				// also make sure to delete everything inside the cart
				customerDisplayFrame.setVisible(false);
				cashierDisplayFrame.setVisible(false);
				
			}
			
		});
		
		return noneButton;
	}
	
	JButton createConfirmButton() {
		
		confirmButton = new JButton("CONFIRM");
		confirmButton.setBounds(600,40,250,100);
		confirmButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				//checkOutFrame();
				//switchToCheckOutFrame();
				
			}
			
		});
		
		return noneButton;
	}
	
	JTextField createWeightTextField() {
		
		weightTextField = new JTextField();
		weightTextField.setBounds(395,50,70,50);
		
		return weightTextField;
		
	}
	
	JButton createOneButton() {
		
		oneButton = new JButton("1");
		oneButton.setBounds(200,90,50,50);

		
		oneButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("1");
				
			}
			
			
		});
		
		return oneButton;
		
		
	}
	
	JButton createTwoButton() {
		
		twoButton = new JButton("2");
		twoButton.setBounds(260,90,50,50);
		
		twoButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("2");
				
			}
			
		});
		
		return twoButton;
		
	}
	
	JButton createThreeButton() {
		
		threeButton = new JButton("3");
		threeButton.setBounds(320,90,50,50);
		
		threeButton.addActionListener( new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("3");
				
			}
			
		});
		
		return threeButton;
		
	}
	
	JButton createFourButton() {
		
		fourButton = new JButton("4");
		fourButton.setBounds(200,140,50,50);
		
		
		fourButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("4");
				
			}
			
		});
		
		return fourButton;
		
	}
	
	JButton createFiveButton() {
		
		fiveButton = new JButton("5");
		fiveButton.setBounds(260,140,50,50);
		
		
		fiveButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("5");
				
			}
			
		});
		
		return fiveButton;
		
	}
	
	JButton createSixButton() {
		
		sixButton = new JButton("6");
		sixButton.setBounds(320,140,50,50);
		
		
		sixButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("6");
				
			}
			
		});
		
		
		return sixButton;
		
	}
	
	JButton createSevenButton() {
		
		sevenButton = new JButton("7");
		sevenButton.setBounds(200,190,50,50);
		
		
		sevenButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("7");
				
			}
			
		});
		
		
		return sevenButton;
		
	}
	
	JButton createEightButton() {
		
		eightButton = new JButton("8");
		eightButton.setBounds(260,190,50,50);
	
		eightButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("8");
				
			}
			
		});
		
		
		return eightButton;
		
	}
	
	JButton createNineButton() {
		
		nineButton = new JButton("9");
		nineButton.setBounds(320,190,50,50);
		
		nineButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("9");
				
			}
			
		});
		
		
		return nineButton;
		
	}
	
	JButton createZeroButton() {
		
		zeroButton = new JButton("0");
		zeroButton.setBounds(260,240,50,50);
		
		
		zeroButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				TextArea.append("0");
				
			}
			
		});
		
		
		return zeroButton;
		
	}
	
	JButton createDeleteButton() {
		
		deleteButton = new JButton("<-");
		deleteButton.setBounds(200,240,50,50);
		
		
		deleteButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				String temp = TextArea.getText();
				temp = removeLastChar(temp);
				System.out.println(temp);
				TextArea.setText(temp);
				
				
			}
			
		});
		
		
		return deleteButton;
		
	}
	
	JButton createEnterButton() { //enter button for cash
		
		enterButton = new JButton("ENT");
		enterButton.setBounds(320,240,50,50);

		enterButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				String temp = TextArea.getText();
				System.out.println("The amount entered is " + temp);
				System.out.println("choice 1");
				cash = toDouble(temp);

				if(cash >= total) {
					createCashierDisplayPanel3();
					createCustomerDisplayPanel2();
				} else {
					createCustomerDisplayPanel5();
					createCashierDisplayPanel6();
				}

			}
			
		});
		
		
		return enterButton;
		
	}
	
	//used to verify card information after the submit it
	JButton createEnter2Button() {
		
		enterButton2 = new JButton("ENT");
		enterButton2.setBounds(320,240,50,50);
		
		enterButton2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String temp = TextArea.getText();
				System.out.println("The number entered is " + temp);
				System.out.println("choice 2 or 3");
				
				//buffer buff = new buffer();
				//bank bankObj = new bank(buff);
				
				if(num == 0) {
					ccNumber = temp;
					System.out.println("The card number is" + ccNumber);
					customerKeypadDisplayPanel.removeAll();
					customerKeypadDisplayPanel.updateUI();
					if(choice == 2) {
						customerKeypadDisplayPanel.add(createPinLabelDisplayMessage());
						num += 1;
						createNumpad(choice);
					} 
				// for debit card
				} else if(num == 1 && choice == 2) {
					pin = (temp);
					System.out.println("The pin number is" + pin);
					System.out.println("verifying bank info");
					customerKeypadDisplayPanel.removeAll();
					customerKeypadDisplayPanel.updateUI();
					num = 0; 
					/*
					//store storeObj = new store(buff, ccNumber, pin, total);
					store storeObj = new store(buff, "1111111111111111", "1111", 1.00);
					ccNumber and pin should replace the default input
					
					try { 
						bankObj.t.join();
						storeObj.t.join();	
					} catch(InterruptedException e1) {
						System.out.println("Authorization failed");
					}
						
					System.out.println("authorization number: " + buff.reply); // makes sure you are getting back authorization number
					*/
				//for credit card
				} else {
					System.out.println("verifying bank info");
					customerKeypadDisplayPanel.removeAll();
					customerKeypadDisplayPanel.updateUI();		
					//store storeObj = new store(buff, "1111111111111111", "1111", 1.00);
					//store storeObj = new store(buff, ccNumber, "0", total);
					/*
					try { 
						bankObj.t.join();
						storeObj.t.join();	
					} catch(InterruptedException e1) {
						System.out.println("Authorization failed");
					}
						
					System.out.println("authorization number: " + buff.reply); // makes sure you are getting back authorization number
					*/
				}

			}
			
		});
		
		
		return enterButton2;
		
	}
	
	JButton createEnterButton3() { //enter button for cash
		
		enterButton = new JButton("ENT");
		enterButton.setBounds(320,240,50,50);

		enterButton.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				String temp = TextArea.getText();
				System.out.println("The amount entered is " + temp);
				System.out.println("choice 1");
				if(num2 == 0) {
					checkAmount = toDouble(temp);
					System.out.println("The check amount is " + checkAmount);
					num2 += 1;
					cashierDisplayPanel.removeAll();
					cashierDisplayPanel.updateUI();
					cashierDisplayPanel.add(createNameDisplayMessage());
					createNumpad(choice);
				} else if(num2 == 1) {
					name = temp;
					System.out.println("The name is " + name);

				}
			}
			
		});
		
		
		return enterButton;
		
	}
	
	JButton createDotButton() {
		
		dotButton = new JButton(".");
		dotButton.setBounds(260,290,50,50);
		
		
		dotButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
					
				TextArea.append(".");
				
				
			}
			
		});
		
		
		return dotButton;
		
	}
	
	JButton createNewOrderButton() { //used to start a new payment
		newOrderButton = new JButton("New Order");
		newOrderButton.setBounds(100,40,250,100);
		
		newOrderButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				System.out.println("starting a new order");
				
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				customerDisplayPanel.removeAll();
				customerDisplayPanel.updateUI();
				receiptDisplayPanel.removeAll();
				receiptDisplayPanel.updateUI();
				
				cashierDisplayFrame.setVisible(false);
				receiptDisplayFrame.setVisible(false);
				
				System.out.println("reset cart");
				//obj.clearCart();
				
			}
			
		});
		
		return newOrderButton;
	}
	
	JButton createProceedButton() { //used to go back to main menu when payment fails
		proceedButton = new JButton("Proceed");
		proceedButton.setBounds(350,140,250,100);
		
		proceedButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				System.out.println("going back to total screen");
				
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				
				//resetData();
				
				createCashierDisplayPanel();
				createCustomerDisplayFrame();	
				
				
			}
			
		});
		
		return proceedButton;
	}
	
	JButton createProceedButton2() { //used when payment succeeds and resets cart
		proceedButton = new JButton("Proceed");
		proceedButton.setBounds(100,40,250,100);
		
		proceedButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				System.out.println("going back to main menu");
				createRecieptDisplayFrame();
				for(inventory item:cart) {
					//obj2.addPoints(createAccFrame., item.getPoints());
					addCartPoints(item.getPoints() * item.getQuantityPurchased());
					
					/*
					try {
						obj2.decreaseInventoryQuantity(item.getId(), item.getQuantityPurchased());
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (org.json.simple.parser.ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					*/
					
					recieptTextArea.append(item.getName());
					recieptTextArea.append("-----$" + item.getPrice());
					recieptTextArea.append("------Quantity/" + item.getQuantityPurchased());
					if(item.getBulk() == true) {
						recieptTextArea.append("------" + item.getWeight() + "kg\n");
					} else {
						recieptTextArea.append("\n");
					}
					
				}
				recieptTextArea.append("--------------------------------------------\n");
				recieptTextArea.append("pretax: $" + ptTotal + "\n");
				recieptTextArea.append("tax: $" + taxTotal + "\n");
				recieptTextArea.append("total: $" + total + "\n");
				recieptTextArea.append("change: $" + change + "\n");
				if(choice == 2 || choice == 3) {
					recieptTextArea.append("card number: \n");
					recieptTextArea.append("authorization code: \n");
				}
				cashierDisplayPanel.removeAll();
				cashierDisplayPanel.updateUI();
				
				customerDisplayFrame.setVisible(false);
				cashierDisplayPanel.add(createNewOrderButton());
				//cashierDisplayFrame.setVisible(false);
				
			}
			
		});
		
		return proceedButton;
	}
	
	//void addPoints

	JButton createDebitButton() {
		
		debitButton = new JButton("DEBIT");
		debitButton.setBounds(30,120,250,200);
		//
		
		debitButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				System.out.println("debit");
				choice = 2;
				createCustomerDisplayPanel4();
				//String temp = cashAmountTextArea.getText();
				//System.out.println("The amount entered is " + temp);
				
				
			}
			
		});
		
		
		return debitButton;
		
	}
	
	JButton createCreditButton() {
		
		creditButton = new JButton("CREDIT");
		creditButton.setBounds(320,120,250,200);
		
		
		creditButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				System.out.println("credit");
				choice = 3;
				createCustomerDisplayPanel4();
				//String temp = cashAmountTextArea.getText();
				//System.out.println("The amount entered is " + temp);
				
				
			}
			
		});
		
		
		return creditButton;
		
	}
	
	JTextArea createTextArea() {
		
		TextArea = new JTextArea();
		TextArea.setBounds(200,55,170,30);
		
		return TextArea;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
	}
	

}
